# 🚀 GitHub Pages 部署指南

## 完整部署步骤

### 第一步：准备工作

1. 确保你已经安装了 Git 和 Node.js
2. 创建一个 GitHub 账号（如果还没有）

### 第二步：创建GitHub仓库

1. 登录 GitHub
2. 点击右上角的 "+" → "New repository"
3. 填写仓库信息：
   - Repository name: `phd-quest` (或者你想要的名字)
   - Description: "An AI-powered PhD application simulator"
   - Public (必须是public才能用GitHub Pages免费版)
   - 不要勾选 "Initialize with README"
4. 点击 "Create repository"

### 第三步：配置项目

根据你的部署方式，需要修改 `next.config.js`:

#### 情况1: 部署到 username.github.io (根域名)

如果你的仓库名是 `username.github.io` (比如 `hao123.github.io`):

```javascript
// next.config.js - 保持默认，不需要修改
const nextConfig = {
  output: 'export',
  images: {
    unoptimized: true,
  },
}
```

访问地址将是: `https://username.github.io`

#### 情况2: 部署到子路径 (推荐)

如果你的仓库名是 `phd-quest` (或其他名字):

```javascript
// next.config.js - 取消注释下面两行
const nextConfig = {
  output: 'export',
  images: {
    unoptimized: true,
  },
  basePath: '/phd-quest',  // 👈 取消这行注释
  assetPrefix: '/phd-quest',  // 👈 取消这行注释
}
```

访问地址将是: `https://username.github.io/phd-quest`

### 第四步：上传代码到GitHub

在项目根目录打开终端，执行以下命令：

```bash
# 初始化Git仓库
git init

# 添加所有文件
git add .

# 提交代码
git commit -m "Initial commit: PhD Quest game"

# 连接到你的GitHub仓库（替换成你的用户名和仓库名）
git remote add origin https://github.com/YOUR_USERNAME/phd-quest.git

# 推送到GitHub
git branch -M main
git push -u origin main
```

### 第五步：配置GitHub Pages

1. 在GitHub仓库页面，点击 "Settings"
2. 左侧菜单找到 "Pages"
3. 在 "Build and deployment" 部分：
   - Source: 选择 "GitHub Actions"
4. 保存

### 第六步：等待部署完成

1. 点击仓库顶部的 "Actions" 标签
2. 你会看到一个 "Deploy to GitHub Pages" 的workflow正在运行
3. 等待绿色勾号 ✅ 出现（通常需要2-3分钟）
4. 部署完成后，访问你的网站！

## 📝 访问地址

根据你的配置：
- **根域名**: `https://YOUR_USERNAME.github.io`
- **子路径**: `https://YOUR_USERNAME.github.io/phd-quest`

## 🔧 后续更新

每次你想更新网站：

```bash
# 修改代码后
git add .
git commit -m "描述你的修改"
git push

# GitHub Actions会自动重新部署
```

## ❓ 常见问题

### Q1: 部署后页面显示404

**解决方案**: 检查 `next.config.js` 中的 `basePath` 设置是否与仓库名匹配

### Q2: CSS样式丢失

**解决方案**: 确保 `next.config.js` 中设置了 `images: { unoptimized: true }`

### Q3: GitHub Actions失败

**解决方案**: 
1. 检查 Settings → Pages → Source 是否选择了 "GitHub Actions"
2. 查看 Actions 标签中的错误日志
3. 确保仓库是 Public

### Q4: 如何使用自定义域名？

1. 购买域名（如 phd-quest.com）
2. 在仓库根目录创建 `public/CNAME` 文件，内容为你的域名
3. 在域名提供商设置DNS记录指向 GitHub Pages
4. 在 GitHub Settings → Pages → Custom domain 添加域名

## 🎉 完成！

现在你的PhD Quest已经在线了！分享给朋友们试玩吧！

## 📊 监控访问量（可选）

你可以添加Google Analytics来追踪访问量：

1. 创建Google Analytics账号
2. 获取跟踪ID
3. 在 `app/layout.tsx` 中添加Analytics脚本

## 🚀 性能优化建议

- 游戏加载很快，因为是静态站点
- 所有数据都在客户端，无需服务器
- 可以通过浏览器的本地存储保存游戏进度

---

需要帮助？提交 Issue 或查看 [Next.js文档](https://nextjs.org/docs)
