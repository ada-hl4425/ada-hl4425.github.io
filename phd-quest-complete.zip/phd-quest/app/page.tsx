import Link from 'next/link';

export default function Home() {
  return (
    <main className="min-h-screen bg-gradient-to-b from-blue-50 via-white to-blue-50">
      <div className="container mx-auto px-4 py-16">
        <div className="max-w-4xl mx-auto text-center">
          {/* Hero Section */}
          <div className="mb-12">
            <h1 className="text-6xl font-bold text-gray-900 mb-6">
              PhD Quest 🎓
            </h1>
            <p className="text-2xl text-gray-600 mb-4">
              海外博士申请模拟器
            </p>
            <p className="text-lg text-gray-500 mb-8">
              体验从套磁到拿offer的完整申请季 • AI驱动的真实叙事
            </p>
            
            <div className="flex gap-4 justify-center">
              <Link
                href="/game"
                className="px-8 py-4 bg-blue-600 text-white rounded-lg text-lg font-semibold hover:bg-blue-700 transition shadow-lg hover:shadow-xl"
              >
                开始游戏 →
              </Link>
            </div>
          </div>

          {/* Features */}
          <div className="grid md:grid-cols-3 gap-8 mb-16">
            <div className="p-6 bg-white rounded-lg shadow-md hover:shadow-lg transition">
              <div className="text-4xl mb-4">📧</div>
              <h3 className="text-xl font-semibold mb-2">真实套磁</h3>
              <p className="text-gray-600">AI生成导师回复，体验套磁的紧张与期待</p>
            </div>
            <div className="p-6 bg-white rounded-lg shadow-md hover:shadow-lg transition">
              <div className="text-4xl mb-4">🎤</div>
              <h3 className="text-xl font-semibold mb-2">模拟面试</h3>
              <p className="text-gray-600">练习应对各种面试问题，提升面试技巧</p>
            </div>
            <div className="p-6 bg-white rounded-lg shadow-md hover:shadow-lg transition">
              <div className="text-4xl mb-4">🎯</div>
              <h3 className="text-xl font-semibold mb-2">多重结局</h3>
              <p className="text-gray-600">每个选择都有影响，体验不同的申请路径</p>
            </div>
          </div>

          {/* Game Info */}
          <div className="bg-white rounded-lg shadow-md p-8 text-left">
            <h2 className="text-2xl font-bold mb-4">游戏特色</h2>
            <ul className="space-y-3 text-gray-700">
              <li className="flex items-start gap-3">
                <span className="text-green-600 font-bold">✓</span>
                <span><strong>真实的申请流程：</strong>从研究导师、套磁邮件、准备材料到面试，完整还原申请季</span>
              </li>
              <li className="flex items-start gap-3">
                <span className="text-green-600 font-bold">✓</span>
                <span><strong>AI驱动叙事：</strong>每个导师都有独特的性格，邮件回复都是AI实时生成</span>
              </li>
              <li className="flex items-start gap-3">
                <span className="text-green-600 font-bold">✓</span>
                <span><strong>动态事件系统：</strong>导师突然不招生、推荐人跑路、论文被接收...各种真实场景</span>
              </li>
              <li className="flex items-start gap-3">
                <span className="text-green-600 font-bold">✓</span>
                <span><strong>多维度评分：</strong>GPA、论文、套磁技巧、运气值...多种因素影响申请结果</span>
              </li>
              <li className="flex items-start gap-3">
                <span className="text-green-600 font-bold">✓</span>
                <span><strong>真实学校数据：</strong>基于真实的QS排名、申请截止日期、funding情况</span>
              </li>
            </ul>
          </div>

          {/* Stats */}
          <div className="mt-16 grid md:grid-cols-4 gap-6">
            <div className="text-center">
              <div className="text-3xl font-bold text-blue-600">7+</div>
              <div className="text-sm text-gray-600 mt-1">顶尖大学</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-blue-600">10+</div>
              <div className="text-sm text-gray-600 mt-1">真实导师</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-blue-600">AI</div>
              <div className="text-sm text-gray-600 mt-1">智能生成</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-blue-600">∞</div>
              <div className="text-sm text-gray-600 mt-1">可能性</div>
            </div>
          </div>

          {/* Footer */}
          <div className="mt-16 pt-8 border-t text-sm text-gray-500">
            <p>
              灵感来自 <a href="https://tenure.hqzhou.com" target="_blank" rel="noopener" className="text-blue-600 hover:underline">青椒模拟器</a>
            </p>
            <p className="mt-2">
              Made with ❤️ for PhD applicants worldwide
            </p>
          </div>
        </div>
      </div>
    </main>
  );
}
