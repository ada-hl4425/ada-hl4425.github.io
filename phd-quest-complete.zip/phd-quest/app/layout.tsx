import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "PhD Quest - PhD Application Simulator",
  description: "An AI-powered interactive game simulating the overseas PhD application journey",
  keywords: "PhD, application, simulator, game, AI, overseas",
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
