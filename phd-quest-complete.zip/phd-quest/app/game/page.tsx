'use client';

import { useGameStore } from '@/lib/store/gameStore';
import CharacterCreator from '@/components/CharacterCreation/CharacterCreator';
import GameDashboard from '@/components/GameInterface/GameDashboard';

export default function GamePage() {
  const { currentPhase } = useGameStore();

  return (
    <>
      {currentPhase === 'Character Creation' ? (
        <CharacterCreator />
      ) : (
        <GameDashboard />
      )}
    </>
  );
}
