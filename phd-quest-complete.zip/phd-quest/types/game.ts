// types/game.ts
// 游戏核心类型定义

export interface Player {
  id: string;
  name: string;
  // 学术背景
  education: {
    university: string;
    major: string;
    gpa: number; // 0-4.0
    rank: 'Top 2' | 'Top 10' | 'Top 30' | 'Other';
  };
  // 研究经历
  research: {
    papers: number;
    conferences: number;
    projects: number;
    hasTopPaper: boolean; // 是否有顶会论文
  };
  // 标准化考试
  tests: {
    toefl?: number; // 0-120
    ielts?: number; // 0-9
    gre?: number; // 260-340
  };
  // 技能和属性
  skills: {
    coding: number; // 1-10
    writing: number; // 1-10
    presentation: number; // 1-10
    networking: number; // 1-10 (套磁技巧)
  };
  // 推荐信
  recommendations: {
    quality: 'Excellent' | 'Good' | 'Average';
    recommenders: Recommender[];
  };
  // 研究兴趣
  researchInterest: string;
  targetField: ResearchField;
  // 游戏属性
  luck: number; // 1-10，影响随机事件
  stress: number; // 0-100，压力值
  money: number; // 申请费用
}

export type ResearchField = 
  | 'Environmental Science'
  | 'Machine Learning'
  | 'Atmospheric Chemistry'
  | 'Climate Modeling'
  | 'Data Science'
  | 'Computer Vision'
  | 'NLP';

export interface Recommender {
  name: string;
  title: string;
  reputation: 'Famous' | 'Well-known' | 'Regular';
  relationship: 'PhD Advisor' | 'Professor' | 'Industry Mentor';
  reliability: number; // 1-10，会不会跑路
}

export interface University {
  id: string;
  name: string;
  ranking: number; // QS/US News排名
  location: string;
  country: 'UK' | 'US' | 'Germany' | 'Switzerland' | 'Canada' | 'Netherlands';
  reputation: number; // 1-10
  fundingAvailability: number; // 1-10
  competitiveness: number; // 1-10
  applicationFee: number;
  deadline: string; // 申请截止日期
}

export interface Supervisor {
  id: string;
  name: string;
  university: string;
  field: ResearchField;
  reputation: number; // 1-10
  personality: 'Friendly' | 'Strict' | 'Chill' | 'Mysterious';
  responseRate: number; // 0-100，回复套磁邮件的概率
  hasPosition: boolean; // 是否有名额
  fundingStatus: 'Full' | 'Partial' | 'None';
  studentCount: number;
  recentPapers: number;
  matchScore?: number; // 与申请者的匹配度，游戏中计算
}

export interface Application {
  id: string;
  university: University;
  supervisor: Supervisor;
  status: ApplicationStatus;
  submittedDate?: Date;
  // 申请材料质量
  materials: {
    sop: number; // 1-10
    cv: number; // 1-10
    researchProposal?: number; // 1-10
  };
  // 申请结果
  interviewDate?: Date;
  interviewScore?: number;
  finalDecision?: 'Offer' | 'Rejection' | 'Waitlist';
  offerDetails?: OfferDetails;
}

export type ApplicationStatus = 
  | 'Not Started'
  | 'Researching'
  | 'Contacting Supervisor'
  | 'Preparing Materials'
  | 'Submitted'
  | 'Interview Scheduled'
  | 'Interview Completed'
  | 'Waiting for Decision'
  | 'Offer Received'
  | 'Rejected'
  | 'Waitlisted';

export interface OfferDetails {
  funding: 'Full' | 'Partial' | 'None';
  stipend?: number; // 年薪
  duration: number; // 年数
  startDate: string;
  conditions?: string[]; // 附加条件
}

export interface Email {
  id: string;
  from: string;
  to: string;
  subject: string;
  content: string;
  timestamp: Date;
  read: boolean;
  type: 'Sent' | 'Received';
  relatedSupervisor?: string; // 相关导师ID
}

export interface GameEvent {
  id: string;
  type: EventType;
  title: string;
  description: string;
  timestamp: Date;
  choices?: Choice[];
  impact?: EventImpact;
  triggered: boolean;
}

export type EventType = 
  | 'supervisor_no_position' // 导师突然不招生
  | 'paper_accepted' // 论文被接收
  | 'paper_rejected' // 论文被拒
  | 'recommender_issue' // 推荐信问题
  | 'conference_meeting' // 会议遇到导师
  | 'competitor_same_position' // 竞争者
  | 'scholarship_opportunity' // 奖学金机会
  | 'deadline_approaching' // 截止日期临近
  | 'supervisor_response' // 导师回复
  | 'interview_invitation' // 面试邀请
  | 'random_good_luck' // 随机好运
  | 'random_bad_luck'; // 随机厄运

export interface Choice {
  id: string;
  text: string;
  impact: EventImpact;
}

export interface EventImpact {
  stress?: number;
  money?: number;
  luck?: number;
  skills?: Partial<Player['skills']>;
  applicationQuality?: number;
}

export interface GameState {
  player: Player;
  currentPhase: GamePhase;
  gameWeek: number; // 游戏周数（1-52周，模拟一年）
  applications: Application[];
  emails: Email[];
  events: GameEvent[];
  unlockedAchievements: string[];
  statistics: GameStatistics;
}

export type GamePhase = 
  | 'Character Creation'
  | 'Research Phase' // 调研学校和导师
  | 'Networking Phase' // 套磁
  | 'Application Phase' // 准备和提交申请
  | 'Interview Phase' // 面试
  | 'Decision Phase' // 等待和决定
  | 'Game Over';

export interface GameStatistics {
  emailsSent: number;
  emailsReceived: number;
  applicationsSubmitted: number;
  interviewsCompleted: number;
  offersReceived: number;
  rejectionsReceived: number;
  totalMoneySpent: number;
  maxStressLevel: number;
}

export interface Achievement {
  id: string;
  name: string;
  description: string;
  icon: string;
  unlocked: boolean;
  condition: (state: GameState) => boolean;
}

// AI相关类型
export interface AIPromptContext {
  player: Player;
  supervisor: Supervisor;
  emailHistory?: Email[];
  applicationStatus?: Application;
  eventContext?: string;
}

export interface AIResponse {
  content: string;
  tone: 'Positive' | 'Neutral' | 'Negative' | 'Encouraging';
  nextActions?: string[];
}
