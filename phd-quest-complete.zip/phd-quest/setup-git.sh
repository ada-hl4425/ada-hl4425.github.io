#!/bin/bash

echo "=========================================="
echo "PhD Quest - Git Setup Helper"
echo "=========================================="
echo ""

# 检查是否已经初始化
if [ -d ".git" ]; then
    echo "⚠️  Git repository already initialized!"
    echo ""
    read -p "Do you want to re-initialize? (y/n) " -n 1 -r
    echo ""
    if [[ ! $REPLY =~ ^[Yy]$ ]]; then
        exit 0
    fi
    rm -rf .git
fi

echo "Step 1: Initializing Git repository..."
git init
echo "✓ Git initialized"
echo ""

echo "Step 2: Adding all files..."
git add .
echo "✓ Files added"
echo ""

echo "Step 3: Creating initial commit..."
git commit -m "Initial commit: PhD Quest - PhD Application Simulator"
echo "✓ Initial commit created"
echo ""

echo "Step 4: Setting up GitHub remote..."
echo ""
echo "Please enter your GitHub repository URL"
echo "Format: https://github.com/YOUR_USERNAME/phd-quest.git"
read -p "Repository URL: " REPO_URL

if [ -z "$REPO_URL" ]; then
    echo "⚠️  No URL provided. Skipping remote setup."
    echo "You can add it later with: git remote add origin YOUR_URL"
else
    git remote add origin "$REPO_URL"
    echo "✓ Remote added"
    echo ""
    
    echo "Step 5: Pushing to GitHub..."
    git branch -M main
    
    echo ""
    echo "Attempting to push..."
    git push -u origin main
    
    if [ $? -eq 0 ]; then
        echo ""
        echo "=========================================="
        echo "✅ Successfully pushed to GitHub!"
        echo "=========================================="
        echo ""
        echo "Next steps:"
        echo "1. Go to your repository on GitHub"
        echo "2. Click Settings → Pages"
        echo "3. Under 'Build and deployment', select 'GitHub Actions'"
        echo "4. Wait 2-3 minutes for deployment"
        echo "5. Your site will be live! 🎉"
        echo ""
    else
        echo ""
        echo "⚠️  Push failed. You may need to:"
        echo "1. Configure Git credentials"
        echo "2. Check repository permissions"
        echo "3. Manually push with: git push -u origin main"
    fi
fi

echo ""
echo "=========================================="
echo "Git setup complete!"
echo "=========================================="
