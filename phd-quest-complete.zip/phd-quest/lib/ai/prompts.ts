// lib/ai/prompts.ts
// AI Prompt 设计 - 用于生成个性化的游戏内容

import { Player, Supervisor, Email, Application } from '@/types/game';

export class PromptBuilder {
  // 1. 导师回复套磁邮件
  static supervisorEmailResponse(context: {
    player: Player;
    supervisor: Supervisor;
    playerEmail: string;
    emailHistory?: Email[];
  }): string {
    const { player, supervisor, playerEmail } = context;
    
    return `You are Professor ${supervisor.name}, a ${supervisor.personality.toLowerCase()} ${supervisor.field} researcher at ${supervisor.university}. 

Your Profile:
- Reputation in field: ${supervisor.reputation}/10
- Current students: ${supervisor.studentCount}
- Recent publications: ${supervisor.recentPapers}
- Available position: ${supervisor.hasPosition ? 'Yes' : 'No'}
- Funding status: ${supervisor.fundingStatus}
- Personality: ${supervisor.personality}

You've received the following email from a prospective PhD student:

"""
${playerEmail}
"""

Student's Background:
- Education: ${player.education.major} from ${player.education.university} (GPA: ${player.education.gpa})
- Research: ${player.research.papers} papers, ${player.research.conferences} conferences
- Research interest: ${player.researchInterest}
- Top paper: ${player.research.hasTopPaper ? 'Yes' : 'No'}

Based on your personality and current situation, write a realistic email response. Consider:
1. Whether you have a position available
2. The quality of the student's background and research fit
3. Your personality type (${supervisor.personality})
4. Common academic email etiquette

The response should be:
- Professional but match your personality
- ${supervisor.hasPosition ? 'Welcoming if interested, or politely declining if not a good fit' : 'Politely explain you have no positions, but be encouraging'}
- 100-200 words
- Include realistic next steps if interested

Write ONLY the email content, no meta-commentary.`;
  }

  // 2. 面试问题生成
  static generateInterviewQuestions(context: {
    supervisor: Supervisor;
    player: Player;
    application: Application;
  }): string {
    const { supervisor, player, application } = context;
    
    return `You are Professor ${supervisor.name} conducting a PhD interview. Generate 5 interview questions for this candidate.

Candidate Background:
- Research area: ${player.researchInterest}
- Previous work: ${player.research.papers} papers, ${player.research.projects} projects
- Statement quality: ${application.materials.sop}/10

Your research focus: ${supervisor.field}

Generate:
1. One technical question about their research background
2. One question about their future research plans
3. One question testing their knowledge of your research area
4. One question about their problem-solving ability
5. One personal question about their motivation/fit

Format as JSON array:
[
  {
    "type": "technical",
    "question": "...",
    "difficulty": "medium"
  },
  ...
]`;
  }

  // 3. SOP评价和改进建议
  static evaluateSOPDraft(context: {
    sopContent: string;
    player: Player;
    targetSupervisor: Supervisor;
  }): string {
    const { sopContent, player, targetSupervisor } = context;
    
    return `You are an experienced PhD admissions advisor. Evaluate this Statement of Purpose and provide a score (1-10) with detailed feedback.

Target Position:
- Supervisor: Professor ${targetSupervisor.name}
- Field: ${targetSupervisor.field}
- University reputation: ${targetSupervisor.reputation}/10

Candidate Background:
- GPA: ${player.education.gpa}
- Research: ${player.research.papers} papers
- Skills: Coding ${player.skills.coding}/10, Writing ${player.skills.writing}/10

Statement of Purpose:
"""
${sopContent}
"""

Provide feedback in JSON format:
{
  "score": <1-10>,
  "strengths": ["...", "..."],
  "weaknesses": ["...", "..."],
  "suggestions": ["...", "..."],
  "overallImpression": "...",
  "fitScore": <1-10>
}

Be honest but constructive. Consider:
- Research motivation clarity
- Fit with supervisor's research
- Writing quality
- Specificity of research plans
- Demonstration of background knowledge`;
  }

  // 4. 随机事件叙事
  static generateGameEvent(context: {
    eventType: string;
    player: Player;
    gameWeek: number;
    relatedApplication?: Application;
  }): string {
    const { eventType, player, gameWeek } = context;
    
    return `Generate a realistic academic/PhD application event for a text-based game.

Event Type: ${eventType}
Current Week: ${gameWeek}/52 (application season)
Player's stress level: ${player.stress}/100

Player Context:
- Applied to ${context.relatedApplication ? 'multiple programs' : 'programs'}
- Research area: ${player.researchInterest}
- Current mood: ${player.stress > 70 ? 'Very stressed' : player.stress > 40 ? 'Moderately anxious' : 'Relatively calm'}

Generate the event in JSON format:
{
  "title": "Short title (5-8 words)",
  "description": "Detailed description (100-150 words) that creates tension and realism",
  "choices": [
    {
      "text": "Choice 1 description",
      "impact": {
        "stress": <-10 to +10>,
        "luck": <-2 to +2>,
        "money": <cost if any>
      }
    },
    // 2-3 meaningful choices
  ]
}

Make it feel real and emotionally engaging, like actual PhD applicants experience.`;
  }

  // 5. Offer/Rejection Letter生成
  static generateDecisionLetter(context: {
    decision: 'Offer' | 'Rejection' | 'Waitlist';
    application: Application;
    player: Player;
  }): string {
    const { decision, application, player } = context;
    
    return `Generate a realistic ${decision.toLowerCase()} letter from ${application.university.name}.

Application Details:
- Supervisor: ${application.supervisor.name}
- Field: ${application.supervisor.field}
- Interview score: ${application.interviewScore || 'N/A'}/10

Candidate Performance:
- SOP quality: ${application.materials.sop}/10
- Research background: ${player.research.papers} papers
- Interview: ${application.interviewScore ? 'Completed' : 'Not done'}

${decision === 'Offer' ? `
Include:
- Congratulations message
- Brief mention of what impressed the committee
- Funding details (${application.supervisor.fundingStatus})
- Next steps and deadline to accept
- Realistic stipend amount for ${application.university.country}
` : decision === 'Rejection' ? `
Include:
- Professional but kind rejection
- Brief generic reason (competitive applicant pool)
- Encouragement for future endeavors
- Standard academic politeness
` : `
Include:
- Waitlist notification
- Explanation of current status
- Timeline for final decision
- What they can do while waiting
`}

Write a formal academic letter (200-300 words). Make it realistic and emotionally appropriate.`;
  }

  // 6. 套磁邮件模板建议
  static suggestEmailTemplate(context: {
    player: Player;
    supervisor: Supervisor;
    purpose: 'initial' | 'followup' | 'after-interview';
  }): string {
    const { player, supervisor, purpose } = context;
    
    return `Suggest a professional email template for contacting a potential PhD supervisor.

Purpose: ${purpose === 'initial' ? 'First contact' : purpose === 'followup' ? 'Follow-up email' : 'Post-interview thank you'}

Student Background:
- Name: ${player.name}
- Current: ${player.education.major} student at ${player.education.university}
- Research: ${player.researchInterest}
- Publications: ${player.research.papers} papers

Target Supervisor:
- Name: Professor ${supervisor.name}
- University: ${supervisor.university}
- Field: ${supervisor.field}
- Personality: ${supervisor.personality}

Provide:
1. A suggested email template (150-200 words)
2. Key points to include
3. Things to avoid
4. Expected response rate: <percentage>

Format as JSON:
{
  "template": "email content...",
  "keyPoints": ["...", "..."],
  "toAvoid": ["...", "..."],
  "tips": ["...", "..."],
  "expectedResponseRate": <0-100>
}

Make it professional but authentic, not overly formal or templated.`;
  }

  // 7. 面试反馈生成
  static generateInterviewFeedback(context: {
    answers: { question: string; answer: string }[];
    supervisor: Supervisor;
    player: Player;
  }): string {
    const { answers, supervisor, player } = context;
    
    return `You are Professor ${supervisor.name} evaluating a PhD interview candidate.

Your personality: ${supervisor.personality}
Research area: ${supervisor.field}

Candidate's answers:
${answers.map((a, i) => `Q${i + 1}: ${a.question}\nA${i + 1}: ${a.answer}`).join('\n\n')}

Candidate's background:
- Presentation skills: ${player.skills.presentation}/10
- Research experience: ${player.research.papers} papers

Provide honest interview feedback in JSON format:
{
  "overallScore": <1-10>,
  "strengths": ["...", "..."],
  "concerns": ["...", "..."],
  "detailedFeedback": "150-200 word evaluation",
  "recommendation": "Strong Accept" | "Accept" | "Borderline" | "Reject",
  "personalComment": "Brief personal note from the supervisor's perspective"
}

Be realistic - perfect scores are rare, some concerns are normal.`;
  }

  // 8. 游戏旁白/叙事生成
  static generateNarrative(context: {
    phase: string;
    playerState: Player;
    recentEvents: string[];
  }): string {
    const { phase, playerState, recentEvents } = context;
    
    return `Generate engaging narrative text for a PhD application simulator game.

Current Phase: ${phase}
Player's stress: ${playerState.stress}/100
Recent events: ${recentEvents.join(', ')}

Generate 2-3 short narrative paragraphs (100-150 words total) that:
1. Set the scene and mood
2. Reflect the player's current emotional state
3. Build anticipation for what's coming
4. Feel authentic to the PhD application experience

Tone: Mix of humor, realism, and encouragement. Like a friend who's been through the process.

Examples of good tone:
- "You stare at your inbox for the 47th time today. Still nothing from Cambridge. Your friend just got an offer from MIT. You refresh again. Still nothing. This is fine. Everything is fine."
- "Three months of coding, two rejected papers, and one existential crisis later, you finally have something to show in your SOP. Is it enough? Who knows. But at least it's honest."

Write in second person ("You..."). Make it relatable and slightly dramatic.`;
  }
}

// Helper function to call AI API (simplified)
export async function callClaudeAPI(prompt: string): Promise<string> {
  // 这里实现实际的API调用
  // 使用 Anthropic Claude API 或 OpenAI API
  
  const response = await fetch('https://api.anthropic.com/v1/messages', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'x-api-key': process.env.ANTHROPIC_API_KEY || '',
      'anthropic-version': '2023-06-01',
    },
    body: JSON.stringify({
      model: 'claude-3-5-sonnet-20241022',
      max_tokens: 1024,
      messages: [
        {
          role: 'user',
          content: prompt,
        },
      ],
    }),
  });

  const data = await response.json();
  return data.content[0].text;
}
