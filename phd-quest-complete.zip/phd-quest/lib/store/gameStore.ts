// lib/store/gameStore.ts
import { create } from 'zustand';
import { GameState, Player, Application, Email, GameEvent, GamePhase } from '@/types/game';

interface GameStore extends GameState {
  // Actions
  setPlayer: (player: Player) => void;
  setPhase: (phase: GamePhase) => void;
  advanceWeek: () => void;
  addEmail: (email: Email) => void;
  markEmailAsRead: (emailId: string) => void;
  addApplication: (application: Application) => void;
  updateApplication: (id: string, updates: Partial<Application>) => void;
  addEvent: (event: GameEvent) => void;
  triggerEvent: (eventId: string) => void;
  updatePlayerStats: (updates: Partial<Player>) => void;
  resetGame: () => void;
}

const initialPlayer: Player = {
  id: 'player-1',
  name: '',
  education: {
    university: '',
    major: '',
    gpa: 3.5,
    rank: 'Top 30',
  },
  research: {
    papers: 0,
    conferences: 0,
    projects: 0,
    hasTopPaper: false,
  },
  tests: {
    toefl: 100,
    gre: 320,
  },
  skills: {
    coding: 5,
    writing: 5,
    presentation: 5,
    networking: 5,
  },
  recommendations: {
    quality: 'Good',
    recommenders: [],
  },
  researchInterest: '',
  targetField: 'Environmental Science',
  luck: 5,
  stress: 30,
  money: 5000,
};

const initialState: GameState = {
  player: initialPlayer,
  currentPhase: 'Character Creation',
  gameWeek: 1,
  applications: [],
  emails: [],
  events: [],
  unlockedAchievements: [],
  statistics: {
    emailsSent: 0,
    emailsReceived: 0,
    applicationsSubmitted: 0,
    interviewsCompleted: 0,
    offersReceived: 0,
    rejectionsReceived: 0,
    totalMoneySpent: 0,
    maxStressLevel: 30,
  },
};

export const useGameStore = create<GameStore>((set, get) => ({
  ...initialState,

  setPlayer: (player) => set({ player }),

  setPhase: (phase) => set({ currentPhase: phase }),

  advanceWeek: () => set((state) => ({ 
    gameWeek: state.gameWeek + 1 
  })),

  addEmail: (email) => set((state) => ({
    emails: [email, ...state.emails],
    statistics: {
      ...state.statistics,
      emailsSent: email.type === 'Sent' ? state.statistics.emailsSent + 1 : state.statistics.emailsSent,
      emailsReceived: email.type === 'Received' ? state.statistics.emailsReceived + 1 : state.statistics.emailsReceived,
    },
  })),

  markEmailAsRead: (emailId) => set((state) => ({
    emails: state.emails.map(email =>
      email.id === emailId ? { ...email, read: true } : email
    ),
  })),

  addApplication: (application) => set((state) => ({
    applications: [...state.applications, application],
  })),

  updateApplication: (id, updates) => set((state) => ({
    applications: state.applications.map(app =>
      app.id === id ? { ...app, ...updates } : app
    ),
    statistics: updates.finalDecision === 'Offer' ? {
      ...state.statistics,
      offersReceived: state.statistics.offersReceived + 1,
    } : updates.finalDecision === 'Rejection' ? {
      ...state.statistics,
      rejectionsReceived: state.statistics.rejectionsReceived + 1,
    } : state.statistics,
  })),

  addEvent: (event) => set((state) => ({
    events: [...state.events, event],
  })),

  triggerEvent: (eventId) => set((state) => ({
    events: state.events.map(event =>
      event.id === eventId ? { ...event, triggered: true } : event
    ),
  })),

  updatePlayerStats: (updates) => set((state) => ({
    player: { ...state.player, ...updates },
    statistics: {
      ...state.statistics,
      maxStressLevel: Math.max(
        state.statistics.maxStressLevel,
        updates.stress || state.player.stress
      ),
    },
  })),

  resetGame: () => set(initialState),
}));
