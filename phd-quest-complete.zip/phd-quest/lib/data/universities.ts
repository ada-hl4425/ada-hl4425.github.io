// lib/data/universities.ts
// 示例大学和导师数据

import { University, Supervisor, ResearchField } from '@/types/game';

export const UNIVERSITIES: University[] = [
  {
    id: 'cambridge',
    name: 'University of Cambridge',
    ranking: 3,
    location: 'Cambridge, UK',
    country: 'UK',
    reputation: 10,
    fundingAvailability: 8,
    competitiveness: 10,
    applicationFee: 75,
    deadline: '2026-01-07', // 和你的真实deadline一样！
  },
  {
    id: 'oxford',
    name: 'University of Oxford',
    ranking: 4,
    location: 'Oxford, UK',
    country: 'UK',
    reputation: 10,
    fundingAvailability: 8,
    competitiveness: 10,
    applicationFee: 75,
    deadline: '2026-01-15',
  },
  {
    id: 'eth',
    name: 'ETH Zurich',
    ranking: 7,
    location: 'Zurich, Switzerland',
    country: 'Switzerland',
    reputation: 9,
    fundingAvailability: 9,
    competitiveness: 9,
    applicationFee: 150,
    deadline: '2025-12-15',
  },
  {
    id: 'imperial',
    name: 'Imperial College London',
    ranking: 6,
    location: 'London, UK',
    country: 'UK',
    reputation: 9,
    fundingAvailability: 7,
    competitiveness: 9,
    applicationFee: 75,
    deadline: '2026-01-31',
  },
  {
    id: 'mit',
    name: 'Massachusetts Institute of Technology',
    ranking: 1,
    location: 'Cambridge, MA, USA',
    country: 'US',
    reputation: 10,
    fundingAvailability: 9,
    competitiveness: 10,
    applicationFee: 95,
    deadline: '2025-12-15',
  },
  {
    id: 'stanford',
    name: 'Stanford University',
    ranking: 5,
    location: 'Stanford, CA, USA',
    country: 'US',
    reputation: 10,
    fundingAvailability: 9,
    competitiveness: 10,
    applicationFee: 125,
    deadline: '2025-12-01',
  },
  {
    id: 'delft',
    name: 'Delft University of Technology',
    ranking: 47,
    location: 'Delft, Netherlands',
    country: 'Netherlands',
    reputation: 8,
    fundingAvailability: 7,
    competitiveness: 7,
    applicationFee: 100,
    deadline: '2026-04-01',
  },
];

export const SUPERVISORS: Supervisor[] = [
  // Cambridge - 基于你真实套磁的导师！
  {
    id: 'archibald',
    name: 'Alex Archibald',
    university: 'University of Cambridge',
    field: 'Atmospheric Chemistry',
    reputation: 9,
    personality: 'Friendly',
    responseRate: 75,
    hasPosition: true,
    fundingStatus: 'Full',
    studentCount: 8,
    recentPapers: 15,
  },
  {
    id: 'turchyn',
    name: 'Alexandra Turchyn',
    university: 'University of Cambridge',
    field: 'Environmental Science',
    reputation: 9,
    personality: 'Strict',
    responseRate: 60,
    hasPosition: true,
    fundingStatus: 'Partial',
    studentCount: 6,
    recentPapers: 12,
  },
  {
    id: 'cambridge_ml',
    name: 'Sarah Thompson',
    university: 'University of Cambridge',
    field: 'Machine Learning',
    reputation: 8,
    personality: 'Chill',
    responseRate: 80,
    hasPosition: false, // 残酷的现实
    fundingStatus: 'None',
    studentCount: 12,
    recentPapers: 20,
  },
  
  // Oxford
  {
    id: 'oxford_climate',
    name: 'James Wilson',
    university: 'University of Oxford',
    field: 'Climate Modeling',
    reputation: 9,
    personality: 'Mysterious',
    responseRate: 50,
    hasPosition: true,
    fundingStatus: 'Full',
    studentCount: 5,
    recentPapers: 18,
  },
  
  // Imperial
  {
    id: 'imperial_env',
    name: 'Emily Chen',
    university: 'Imperial College London',
    field: 'Environmental Science',
    reputation: 8,
    personality: 'Friendly',
    responseRate: 85,
    hasPosition: true,
    fundingStatus: 'Full',
    studentCount: 7,
    recentPapers: 14,
  },
  
  // MIT - 梦校导师
  {
    id: 'mit_ml',
    name: 'Michael Zhang',
    university: 'Massachusetts Institute of Technology',
    field: 'Machine Learning',
    reputation: 10,
    personality: 'Strict',
    responseRate: 30, // 大佬回复率低
    hasPosition: true,
    fundingStatus: 'Full',
    studentCount: 15,
    recentPapers: 25,
  },
  
  // ETH Zurich
  {
    id: 'eth_data',
    name: 'Hans Mueller',
    university: 'ETH Zurich',
    field: 'Data Science',
    reputation: 9,
    personality: 'Chill',
    responseRate: 70,
    hasPosition: true,
    fundingStatus: 'Full',
    studentCount: 10,
    recentPapers: 16,
  },
];

// Helper functions
export function getSupervisorsByUniversity(universityId: string): Supervisor[] {
  return SUPERVISORS.filter(s => 
    UNIVERSITIES.find(u => u.id === universityId)?.name === s.university
  );
}

export function getSupervisorsByField(field: ResearchField): Supervisor[] {
  return SUPERVISORS.filter(s => s.field === field);
}

export function getUniversityById(id: string): University | undefined {
  return UNIVERSITIES.find(u => u.id === id);
}

export function getSupervisorById(id: string): Supervisor | undefined {
  return SUPERVISORS.find(s => s.id === id);
}

// 计算匹配度的算法
export function calculateMatchScore(
  player: { 
    research: { papers: number; hasTopPaper: boolean };
    skills: { coding: number };
    education: { gpa: number };
  },
  supervisor: Supervisor
): number {
  let score = 50; // 基础分
  
  // 论文数量影响
  score += Math.min(player.research.papers * 5, 20);
  
  // 顶会论文加分
  if (player.research.hasTopPaper) {
    score += 15;
  }
  
  // GPA影响
  score += (player.education.gpa - 3.0) * 10;
  
  // 技能匹配
  if (supervisor.field.includes('Machine Learning') || supervisor.field.includes('Data Science')) {
    score += player.skills.coding * 2;
  }
  
  // 导师名气影响（大牛要求更高)
  score -= (supervisor.reputation - 7) * 3;
  
  return Math.max(0, Math.min(100, score));
}
