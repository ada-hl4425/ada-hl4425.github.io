# 🎯 快速命令参考

## 本地开发

```bash
# 安装依赖
npm install

# 启动开发服务器
npm run dev
# 访问 http://localhost:3000

# 构建生产版本
npm run build

# 预览生产版本
npm run start
```

## Git 基本命令

```bash
# 查看状态
git status

# 添加所有修改
git add .

# 提交修改
git commit -m "描述你的修改"

# 推送到GitHub
git push

# 查看提交历史
git log --oneline
```

## 部署到GitHub Pages

### 首次部署

```bash
# 1. 初始化Git
git init

# 2. 添加文件
git add .

# 3. 提交
git commit -m "Initial commit"

# 4. 连接GitHub仓库（替换成你的）
git remote add origin https://github.com/YOUR_USERNAME/phd-quest.git

# 5. 推送
git branch -M main
git push -u origin main
```

### 后续更新

```bash
git add .
git commit -m "更新内容描述"
git push
```

## 常用npm命令

```bash
# 安装新包
npm install package-name

# 移除包
npm uninstall package-name

# 更新所有包
npm update

# 检查过期包
npm outdated

# 清理缓存
npm cache clean --force
```

## 项目结构

```
phd-quest/
├── app/                    # Next.js App Router
│   ├── page.tsx           # 首页
│   ├── game/
│   │   └── page.tsx       # 游戏页面
│   ├── layout.tsx         # 根布局
│   └── globals.css        # 全局样式
├── components/            # React组件
│   ├── CharacterCreation/
│   ├── EmailSystem/
│   └── GameInterface/
├── lib/                   # 工具函数
│   ├── store/            # 状态管理
│   ├── data/             # 游戏数据
│   └── ai/               # AI提示词
├── types/                # TypeScript类型
├── public/               # 静态资源
└── .github/workflows/    # GitHub Actions
```

## 问题排查

### 端口被占用
```bash
# Windows
netstat -ano | findstr :3000
taskkill /PID [PID号] /F

# Mac/Linux
lsof -ti:3000 | xargs kill -9
```

### 重新安装依赖
```bash
rm -rf node_modules package-lock.json
npm install
```

### 清理Next.js缓存
```bash
rm -rf .next
npm run dev
```

## 有用的链接

- [Next.js文档](https://nextjs.org/docs)
- [Tailwind CSS文档](https://tailwindcss.com/docs)
- [GitHub Pages文档](https://docs.github.com/pages)
- [Git教程](https://git-scm.com/doc)
