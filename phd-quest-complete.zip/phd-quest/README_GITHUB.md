# PhD Quest 🎓

An AI-powered interactive game simulating the overseas PhD application journey.

## 🎮 [Play Now](https://yourusername.github.io/phd-quest/)

## Features

- 📧 **Real Email Exchange**: Simulate emailing supervisors and receiving realistic responses
- 🎯 **Multiple Universities**: Choose from top universities like Cambridge, Oxford, MIT, ETH Zurich
- 🧠 **AI-Driven Narrative**: Each supervisor has unique personality and response patterns
- 📊 **Progress Tracking**: Monitor your applications, stress levels, and budget
- 🎲 **Dynamic Events**: Random events like "supervisor runs out of positions" or "paper accepted"

## Tech Stack

- **Frontend**: Next.js 14 + React + TypeScript
- **Styling**: Tailwind CSS
- **State Management**: Zustand
- **Deployment**: GitHub Pages

## Development

```bash
# Install dependencies
npm install

# Run development server
npm run dev

# Build for production
npm run build
```

Visit http://localhost:3000

## Deployment to GitHub Pages

This project automatically deploys to GitHub Pages via GitHub Actions when you push to the main branch.

### Setup Instructions:

1. Create a new repository on GitHub
2. Push this code to your repository
3. Go to repository Settings → Pages
4. Under "Build and deployment", select "GitHub Actions"
5. Push to main branch - automatic deployment will start

## Inspiration

Inspired by [青椒模拟器](https://tenure.hqzhou.com/) - A brilliant game simulating academic career progression.

## License

MIT

## Contributing

Contributions welcome! Feel free to submit issues and pull requests.

---

Made with ❤️ for PhD applicants worldwide
