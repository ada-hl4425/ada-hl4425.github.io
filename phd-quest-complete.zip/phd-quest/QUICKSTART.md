# PhD Quest - 快速开始指南

## 🚀 快速启动

### 1. 创建Next.js项目

```bash
npx create-next-app@latest phd-quest --typescript --tailwind --app
cd phd-quest
```

在设置中选择：
- ✅ TypeScript
- ✅ ESLint
- ✅ Tailwind CSS
- ✅ App Router
- ❌ src/ directory (不需要)
- ✅ Import alias (@/*)

### 2. 安装依赖

```bash
npm install zustand  # 状态管理
npm install date-fns # 日期处理
npm install lucide-react # 图标库
```

### 3. 设置环境变量

创建 `.env.local` 文件：

```env
# Anthropic Claude API
ANTHROPIC_API_KEY=your_api_key_here

# 或者使用 OpenAI
OPENAI_API_KEY=your_openai_key_here
```

获取API Key：
- Claude: https://console.anthropic.com/
- OpenAI: https://platform.openai.com/

### 4. 项目结构

```
phd-quest/
├── app/                    # Next.js App Router
│   ├── page.tsx           # 首页
│   ├── game/              # 游戏主界面
│   │   └── page.tsx
│   ├── layout.tsx         # 根布局
│   └── api/               # API路由
│       └── ai/
│           └── route.ts   # AI API endpoint
├── components/            # React组件
│   ├── EmailSystem/
│   │   ├── EmailComposer.tsx
│   │   └── EmailList.tsx
│   ├── GameInterface/
│   │   ├── Dashboard.tsx
│   │   └── ProgressBar.tsx
│   └── UI/
│       ├── Button.tsx
│       └── Card.tsx
├── lib/                   # 工具和逻辑
│   ├── ai/
│   │   ├── prompts.ts    # AI提示词
│   │   └── client.ts     # API客户端
│   ├── game/
│   │   ├── state.ts      # 游戏状态
│   │   ├── events.ts     # 事件系统
│   │   └── scoring.ts    # 评分逻辑
│   └── data/
│       ├── universities.ts
│       └── supervisors.ts
├── types/
│   └── game.ts           # TypeScript类型
└── public/
    ├── avatars/          # 角色头像
    └── assets/
```

### 5. 创建API路由

创建 `app/api/ai/route.ts`:

```typescript
import { NextRequest, NextResponse } from 'next/server';

export async function POST(request: NextRequest) {
  const { prompt, model = 'claude-3-5-sonnet-20241022' } = await request.json();

  try {
    const response = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': process.env.ANTHROPIC_API_KEY || '',
        'anthropic-version': '2023-06-01',
      },
      body: JSON.stringify({
        model,
        max_tokens: 1024,
        messages: [{ role: 'user', content: prompt }],
      }),
    });

    const data = await response.json();
    return NextResponse.json({ content: data.content[0].text });
  } catch (error) {
    console.error('AI API Error:', error);
    return NextResponse.json({ error: 'Failed to generate response' }, { status: 500 });
  }
}
```

### 6. 创建首页

创建简单的 `app/page.tsx`:

```typescript
import Link from 'next/link';

export default function Home() {
  return (
    <main className="min-h-screen bg-gradient-to-b from-blue-50 to-white">
      <div className="container mx-auto px-4 py-16">
        <div className="max-w-4xl mx-auto text-center">
          <h1 className="text-6xl font-bold text-gray-900 mb-6">
            PhD Quest 🎓
          </h1>
          <p className="text-2xl text-gray-600 mb-4">
            海外博士申请模拟器
          </p>
          <p className="text-lg text-gray-500 mb-12">
            体验从套磁到拿offer的完整申请季 • AI驱动的真实叙事
          </p>
          
          <div className="flex gap-4 justify-center">
            <Link
              href="/game"
              className="px-8 py-4 bg-blue-600 text-white rounded-lg text-lg font-semibold hover:bg-blue-700 transition"
            >
              开始游戏
            </Link>
            <Link
              href="/about"
              className="px-8 py-4 bg-white text-blue-600 border-2 border-blue-600 rounded-lg text-lg font-semibold hover:bg-blue-50 transition"
            >
              了解更多
            </Link>
          </div>

          <div className="mt-16 grid md:grid-cols-3 gap-8">
            <div className="p-6 bg-white rounded-lg shadow-md">
              <div className="text-4xl mb-4">📧</div>
              <h3 className="text-xl font-semibold mb-2">真实套磁</h3>
              <p className="text-gray-600">AI生成导师回复，体验套磁的紧张与期待</p>
            </div>
            <div className="p-6 bg-white rounded-lg shadow-md">
              <div className="text-4xl mb-4">🎤</div>
              <h3 className="text-xl font-semibold mb-2">模拟面试</h3>
              <p className="text-gray-600">练习应对各种面试问题，提升面试技巧</p>
            </div>
            <div className="p-6 bg-white rounded-lg shadow-md">
              <div className="text-4xl mb-4">🎯</div>
              <h3 className="text-xl font-semibold mb-2">多重结局</h3>
              <p className="text-gray-600">每个选择都有影响，体验不同的申请路径</p>
            </div>
          </div>
        </div>
      </div>
    </main>
  );
}
```

### 7. 运行项目

```bash
npm run dev
```

访问 http://localhost:3000

## 📝 MVP开发清单

### Week 1: 基础框架
- [x] 项目初始化
- [x] 类型定义
- [x] 数据结构
- [ ] 基础UI组件
- [ ] 路由设置

### Week 2: 核心功能
- [ ] 角色创建页面
- [ ] 邮件系统UI
- [ ] AI集成（导师回复）
- [ ] 基础游戏状态管理

### Week 3: 游戏逻辑
- [ ] 套磁流程
- [ ] 申请材料系统
- [ ] 简单的评分机制
- [ ] 结果判定

### Week 4: 完善体验
- [ ] UI美化
- [ ] 动画效果
- [ ] 存档功能
- [ ] Bug修复

## 🎨 设计建议

### 配色方案
```css
/* 主色调 - 学术蓝 */
--primary: #2563eb;
--primary-dark: #1e40af;
--primary-light: #60a5fa;

/* 状态颜色 */
--success: #10b981;  /* Offer */
--danger: #ef4444;   /* Rejection */
--warning: #f59e0b;  /* Waitlist */
--info: #3b82f6;     /* 进行中 */

/* 中性色 */
--background: #f9fafb;
--surface: #ffffff;
--text-primary: #111827;
--text-secondary: #6b7280;
```

### 字体
```css
font-family: 'Inter', -apple-system, BlinkMacSystemFont, sans-serif;
```

## 🚢 部署

### Vercel (推荐)
1. 推送代码到GitHub
2. 在Vercel导入项目
3. 添加环境变量
4. 自动部署！

```bash
# 或使用Vercel CLI
npm i -g vercel
vercel
```

### 自定义域名
在Vercel设置中添加你的域名，例如：
- phd-quest.yourname.com
- phd-simulator.com

## 💡 进阶功能想法

1. **数据分析仪表板**
   - 申请成功率
   - 各学校竞争度
   - 最佳策略推荐

2. **社区功能**
   - 分享你的申请故事
   - 查看其他玩家的路径
   - 排行榜

3. **真实数据整合**
   - 整合GradCafe数据
   - CSRankings导师数据
   - 真实时间线

4. **多语言支持**
   - 英文版
   - 中文版（简体/繁体）

5. **移动应用**
   - React Native版本
   - 通知推送（面试提醒）

## 🤝 需要帮助？

如果在实现过程中遇到问题，我可以帮你：
- 调试代码问题
- 优化AI提示词
- 设计UI组件
- 实现特定功能
- 部署指导

## 📚 参考资源

- Next.js文档: https://nextjs.org/docs
- Tailwind CSS: https://tailwindcss.com/docs
- Anthropic API: https://docs.anthropic.com/
- Vercel部署: https://vercel.com/docs

祝开发顺利！这个项目不仅能帮助其他申请者，也能成为你portfolio中的亮点！🚀
