// components/GameInterface/GameDashboard.tsx
'use client';

import { useState } from 'react';
import { useGameStore } from '@/lib/store/gameStore';
import { SUPERVISORS, UNIVERSITIES } from '@/lib/data/universities';
import EmailComposer from '@/components/EmailSystem/EmailComposer';
import { Mail, User, BookOpen, TrendingUp } from 'lucide-react';

export default function GameDashboard() {
  const { player, currentPhase, gameWeek, emails, applications } = useGameStore();
  const [showEmailComposer, setShowEmailComposer] = useState(false);
  const [selectedSupervisor, setSelectedSupervisor] = useState<string | null>(null);

  const unreadEmails = emails.filter(e => !e.read && e.type === 'Received').length;

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b shadow-sm">
        <div className="max-w-7xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-bold text-gray-900">PhD Quest</h1>
              <p className="text-sm text-gray-600">Week {gameWeek} • {currentPhase}</p>
            </div>
            <div className="flex items-center gap-6">
              <div className="text-right">
                <p className="text-sm text-gray-600">Stress Level</p>
                <div className="flex items-center gap-2">
                  <div className="w-32 h-2 bg-gray-200 rounded-full overflow-hidden">
                    <div 
                      className={`h-full ${
                        player.stress > 70 ? 'bg-red-500' : 
                        player.stress > 40 ? 'bg-yellow-500' : 'bg-green-500'
                      }`}
                      style={{ width: `${player.stress}%` }}
                    />
                  </div>
                  <span className="text-sm font-medium">{player.stress}%</span>
                </div>
              </div>
              <div className="text-right">
                <p className="text-sm text-gray-600">Budget</p>
                <p className="font-semibold text-lg">${player.money}</p>
              </div>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 py-6">
        <div className="grid md:grid-cols-3 gap-6">
          {/* Left Sidebar - Player Stats */}
          <div className="md:col-span-1 space-y-4">
            {/* Player Card */}
            <div className="bg-white rounded-lg shadow p-6">
              <div className="flex items-center gap-4 mb-4">
                <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center">
                  <User className="w-8 h-8 text-blue-600" />
                </div>
                <div>
                  <h2 className="font-bold text-lg">{player.name}</h2>
                  <p className="text-sm text-gray-600">{player.education.university}</p>
                </div>
              </div>
              
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span className="text-gray-600">GPA</span>
                  <span className="font-medium">{player.education.gpa.toFixed(2)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Papers</span>
                  <span className="font-medium">{player.research.papers}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">TOEFL</span>
                  <span className="font-medium">{player.tests.toefl}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">GRE</span>
                  <span className="font-medium">{player.tests.gre}</span>
                </div>
              </div>

              <div className="mt-4 pt-4 border-t">
                <p className="text-xs text-gray-600 mb-2">Skills</p>
                <div className="space-y-2">
                  {Object.entries(player.skills).map(([skill, value]) => (
                    <div key={skill}>
                      <div className="flex justify-between text-xs mb-1">
                        <span className="capitalize">{skill}</span>
                        <span>{value}/10</span>
                      </div>
                      <div className="w-full h-1.5 bg-gray-200 rounded-full">
                        <div 
                          className="h-full bg-blue-600 rounded-full"
                          style={{ width: `${value * 10}%` }}
                        />
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Quick Stats */}
            <div className="bg-white rounded-lg shadow p-6">
              <h3 className="font-semibold mb-4">Application Progress</h3>
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <span className="text-sm text-gray-600">Emails Sent</span>
                  <span className="font-semibold">{emails.filter(e => e.type === 'Sent').length}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-gray-600">Replies Received</span>
                  <span className="font-semibold">{emails.filter(e => e.type === 'Received').length}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-gray-600">Applications</span>
                  <span className="font-semibold">{applications.length}</span>
                </div>
              </div>
            </div>
          </div>

          {/* Main Content */}
          <div className="md:col-span-2 space-y-4">
            {/* Action Tabs */}
            <div className="bg-white rounded-lg shadow">
              <div className="border-b">
                <div className="flex gap-1 p-1">
                  <button className="flex-1 py-3 px-4 text-sm font-medium text-blue-600 bg-blue-50 rounded-lg">
                    Find Supervisors
                  </button>
                  <button className="flex-1 py-3 px-4 text-sm font-medium text-gray-600 hover:bg-gray-50 rounded-lg">
                    Inbox ({unreadEmails})
                  </button>
                  <button className="flex-1 py-3 px-4 text-sm font-medium text-gray-600 hover:bg-gray-50 rounded-lg">
                    Applications
                  </button>
                </div>
              </div>

              {/* Supervisor List */}
              <div className="p-6">
                <h3 className="font-semibold text-lg mb-4">Available Supervisors</h3>
                <div className="space-y-3">
                  {SUPERVISORS.slice(0, 6).map((supervisor) => (
                    <div 
                      key={supervisor.id}
                      className="border rounded-lg p-4 hover:border-blue-500 transition cursor-pointer"
                      onClick={() => setSelectedSupervisor(supervisor.id)}
                    >
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <h4 className="font-semibold text-gray-900">
                            Prof. {supervisor.name}
                          </h4>
                          <p className="text-sm text-gray-600">{supervisor.university}</p>
                          <p className="text-sm text-gray-500 mt-1">{supervisor.field}</p>
                        </div>
                        <div className="text-right">
                          <span className={`inline-block px-2 py-1 text-xs rounded-full ${
                            supervisor.hasPosition 
                              ? 'bg-green-100 text-green-700' 
                              : 'bg-red-100 text-red-700'
                          }`}>
                            {supervisor.hasPosition ? 'Hiring' : 'No Position'}
                          </span>
                          <p className="text-xs text-gray-500 mt-1">
                            Response: {supervisor.responseRate}%
                          </p>
                        </div>
                      </div>
                      
                      <div className="mt-3 flex gap-2">
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            setSelectedSupervisor(supervisor.id);
                            setShowEmailComposer(true);
                          }}
                          className="px-4 py-2 bg-blue-600 text-white text-sm rounded-md hover:bg-blue-700"
                        >
                          Send Email
                        </button>
                        <button className="px-4 py-2 border text-sm rounded-md hover:bg-gray-50">
                          View Profile
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Recent Activity */}
            <div className="bg-white rounded-lg shadow p-6">
              <h3 className="font-semibold text-lg mb-4">Recent Activity</h3>
              <div className="space-y-3">
                {emails.slice(0, 3).map((email) => (
                  <div key={email.id} className="flex items-start gap-3 p-3 bg-gray-50 rounded-lg">
                    <Mail className={`w-5 h-5 ${email.read ? 'text-gray-400' : 'text-blue-600'}`} />
                    <div className="flex-1">
                      <p className="text-sm font-medium">{email.subject}</p>
                      <p className="text-xs text-gray-600">
                        {email.type === 'Sent' ? `To ${email.to}` : `From ${email.from}`}
                      </p>
                    </div>
                    <span className="text-xs text-gray-500">
                      {new Date(email.timestamp).toLocaleDateString()}
                    </span>
                  </div>
                ))}
                {emails.length === 0 && (
                  <p className="text-center text-gray-500 py-8">
                    No emails yet. Start by contacting supervisors!
                  </p>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Email Composer Modal */}
      {showEmailComposer && selectedSupervisor && (
        <EmailComposer
          player={player}
          supervisor={SUPERVISORS.find(s => s.id === selectedSupervisor)!}
          onSend={(email) => {
            useGameStore.getState().addEmail(email);
          }}
          onCancel={() => {
            setShowEmailComposer(false);
            setSelectedSupervisor(null);
          }}
        />
      )}
    </div>
  );
}
