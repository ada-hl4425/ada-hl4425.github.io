// components/EmailSystem/EmailComposer.tsx
'use client';

import { useState } from 'react';
import { Player, Supervisor, Email } from '@/types/game';

interface EmailComposerProps {
  player: Player;
  supervisor: Supervisor;
  onSend: (email: Email) => void;
  onCancel: () => void;
}

// 模拟的邮件模板（静态版本，不需要API）
const generateEmailTemplate = (player: Player, supervisor: Supervisor): string => {
  return `Dear Professor ${supervisor.name},

I hope this email finds you well. I am ${player.name}, currently pursuing my ${player.education.major} degree at ${player.education.university}. 

I am writing to express my strong interest in pursuing a PhD in ${player.targetField} under your supervision at ${supervisor.university}. Your recent work in ${supervisor.field} has deeply inspired my research interests, particularly in ${player.researchInterest}.

During my studies, I have ${player.research.papers > 0 ? `published ${player.research.papers} paper(s)` : 'gained research experience'} and developed strong skills in ${player.skills.coding > 7 ? 'computational modeling and programming' : 'research methodology'}. I believe my background aligns well with your research group's focus.

I would be grateful for the opportunity to discuss potential PhD positions in your group. I have attached my CV for your reference.

Thank you for considering my application.

Best regards,
${player.name}`;
};

// 模拟导师回复
const generateSupervisorResponse = (player: Player, supervisor: Supervisor, hasPosition: boolean): string => {
  const responses = {
    friendly_yes: `Dear ${player.name},

Thank you for your email and interest in my research group. Your background looks promising, especially your work in ${player.researchInterest}.

I do have PhD positions available for the upcoming intake. I'd be happy to discuss your research interests further. Could we schedule a video call next week?

Please send me your CV and a brief research proposal (1-2 pages) outlining what you'd like to work on.

Best regards,
Prof. ${supervisor.name}`,
    
    friendly_no: `Dear ${player.name},

Thank you for reaching out and your interest in my research. Your background is impressive.

Unfortunately, I don't have any funded PhD positions available at the moment. However, I encourage you to check our department's general admission page, as there might be scholarship opportunities.

Best of luck with your applications!

Best regards,
Prof. ${supervisor.name}`,
    
    strict_yes: `Dear ${player.name},

I have reviewed your email. Your research background is relevant to my group's work.

I have one position available. The project requires strong programming skills and previous experience in ${supervisor.field}. 

If you are seriously interested, please send:
1. Full CV
2. Research statement (2 pages)
3. Two reference letters

Regards,
Prof. ${supervisor.name}`,
    
    strict_no: `Dear ${player.name},

Thank you for your interest. I currently have no openings.

Regards,
Prof. ${supervisor.name}`,
  };

  const key = `${supervisor.personality.toLowerCase()}_${hasPosition ? 'yes' : 'no'}` as keyof typeof responses;
  return responses[key] || responses.friendly_no;
};

export default function EmailComposer({ 
  player, 
  supervisor, 
  onSend, 
  onCancel 
}: EmailComposerProps) {
  const [subject, setSubject] = useState(`Prospective PhD Student - ${player.researchInterest}`);
  const [content, setContent] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [showHints, setShowHints] = useState(true);

  // 获取模板建议
  const getSuggestion = () => {
    const template = generateEmailTemplate(player, supervisor);
    setContent(template);
  };

  const handleSend = () => {
    if (!content.trim()) {
      alert('Please write something before sending!');
      return;
    }

    setIsLoading(true);
    
    // 创建发送的邮件
    const sentEmail: Email = {
      id: `email-${Date.now()}`,
      from: player.name,
      to: supervisor.name,
      subject,
      content,
      timestamp: new Date(),
      read: true,
      type: 'Sent',
      relatedSupervisor: supervisor.id,
    };

    // 保存发送的邮件
    onSend(sentEmail);

    // 模拟导师回复（基于回复率）
    setTimeout(() => {
      const willReply = Math.random() * 100 < supervisor.responseRate;
      
      if (willReply) {
        const responseContent = generateSupervisorResponse(
          player, 
          supervisor, 
          supervisor.hasPosition
        );
        
        const receivedEmail: Email = {
          id: `email-${Date.now()}-response`,
          from: supervisor.name,
          to: player.name,
          subject: `Re: ${subject}`,
          content: responseContent,
          timestamp: new Date(Date.now() + 1000 * 60 * 60 * 24 * (Math.random() * 3 + 1)), // 1-4天后回复
          read: false,
          type: 'Received',
          relatedSupervisor: supervisor.id,
        };
        
        onSend(receivedEmail);
      }
      
      setIsLoading(false);
      onCancel(); // 关闭编辑器
    }, 2000); // 短暂延迟模拟发送
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-lg shadow-xl max-w-3xl w-full max-h-[90vh] overflow-y-auto">
        {/* Header */}
        <div className="border-b px-6 py-4 flex items-center justify-between">
          <h2 className="text-xl font-semibold text-gray-900">
            New Email to {supervisor.name}
          </h2>
          <button
            onClick={onCancel}
            className="text-gray-400 hover:text-gray-600"
            disabled={isLoading}
          >
            ✕
          </button>
        </div>

        {/* Supervisor Info Card */}
        <div className="px-6 py-4 bg-blue-50 border-b">
          <div className="text-sm space-y-1">
            <p><strong>Professor {supervisor.name}</strong></p>
            <p className="text-gray-600">{supervisor.university}</p>
            <p className="text-gray-600">Field: {supervisor.field}</p>
            <p className="text-gray-600">
              Response Rate: <span className={
                supervisor.responseRate > 70 ? 'text-green-600' :
                supervisor.responseRate > 40 ? 'text-yellow-600' : 'text-red-600'
              }>
                {supervisor.responseRate}%
              </span>
            </p>
            <p className="text-gray-600">
              Has Position: {supervisor.hasPosition ? '✅ Yes' : '❌ No'}
            </p>
          </div>
        </div>

        {/* Email Form */}
        <div className="px-6 py-4 space-y-4">
          {/* Subject */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Subject
            </label>
            <input
              type="text"
              value={subject}
              onChange={(e) => setSubject(e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              disabled={isLoading}
            />
          </div>

          {/* Content */}
          <div>
            <div className="flex items-center justify-between mb-1">
              <label className="block text-sm font-medium text-gray-700">
                Message
              </label>
              <button
                onClick={getSuggestion}
                disabled={isLoading}
                className="text-sm text-blue-600 hover:text-blue-800 disabled:text-gray-400"
              >
                💡 Get AI Suggestion
              </button>
            </div>
            <textarea
              value={content}
              onChange={(e) => setContent(e.target.value)}
              rows={12}
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-transparent font-mono text-sm"
              placeholder="Dear Professor [Name],

I am writing to express my interest in..."
              disabled={isLoading}
            />
            <p className="text-xs text-gray-500 mt-1">
              {content.length} characters • {content.split(/\s+/).filter(Boolean).length} words
            </p>
          </div>

          {/* Hints */}
          {showHints && (
            <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <p className="text-sm font-medium text-yellow-900 mb-2">
                    💡 Email Tips
                  </p>
                  <ul className="text-sm text-yellow-800 space-y-1 list-disc list-inside">
                    <li>Be concise but specific about your research interests</li>
                    <li>Mention 1-2 of their recent papers you've read</li>
                    <li>Explain why you're a good fit for their group</li>
                    <li>Keep it under 250 words for initial contact</li>
                    <li>Proofread carefully - this is your first impression!</li>
                  </ul>
                </div>
                <button
                  onClick={() => setShowHints(false)}
                  className="text-yellow-600 hover:text-yellow-800 ml-2"
                >
                  ✕
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="border-t px-6 py-4 flex items-center justify-between bg-gray-50">
          <div className="text-sm text-gray-600">
            {isLoading && (
              <span className="flex items-center">
                <svg className="animate-spin h-4 w-4 mr-2" viewBox="0 0 24 24">
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none" />
                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
                </svg>
                {content.length === 0 ? 'Generating suggestion...' : 'Sending email...'}
              </span>
            )}
          </div>
          <div className="flex gap-3">
            <button
              onClick={onCancel}
              disabled={isLoading}
              className="px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-md hover:bg-gray-50 disabled:opacity-50"
            >
              Cancel
            </button>
            <button
              onClick={handleSend}
              disabled={isLoading || !content.trim()}
              className="px-4 py-2 text-sm font-medium text-white bg-blue-600 rounded-md hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              Send Email
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
