// components/CharacterCreation/CharacterCreator.tsx
'use client';

import { useState } from 'react';
import { Player, ResearchField } from '@/types/game';
import { useGameStore } from '@/lib/store/gameStore';

const RESEARCH_FIELDS: ResearchField[] = [
  'Environmental Science',
  'Machine Learning',
  'Atmospheric Chemistry',
  'Climate Modeling',
  'Data Science',
  'Computer Vision',
  'NLP',
];

const UNIVERSITIES = [
  'Imperial College London',
  'Tsinghua University',
  'Peking University',
  'Fudan University',
  'Guizhou University',
  'Other',
];

export default function CharacterCreator() {
  const { player, setPlayer, setPhase } = useGameStore();
  const [formData, setFormData] = useState({
    name: '',
    university: '',
    major: 'Environmental Data Science',
    gpa: 3.5,
    papers: 0,
    hasTopPaper: false,
    toefl: 100,
    gre: 320,
    researchInterest: '',
    targetField: 'Environmental Science' as ResearchField,
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    const newPlayer: Player = {
      ...player,
      name: formData.name,
      education: {
        university: formData.university,
        major: formData.major,
        gpa: formData.gpa,
        rank: formData.gpa >= 3.8 ? 'Top 2' : formData.gpa >= 3.6 ? 'Top 10' : 'Top 30',
      },
      research: {
        papers: formData.papers,
        conferences: Math.floor(formData.papers * 0.7),
        projects: 2,
        hasTopPaper: formData.hasTopPaper,
      },
      tests: {
        toefl: formData.toefl,
        gre: formData.gre,
      },
      researchInterest: formData.researchInterest,
      targetField: formData.targetField,
      // 基于背景计算初始技能
      skills: {
        coding: Math.min(10, 5 + Math.floor(formData.papers / 2)),
        writing: Math.min(10, 5 + (formData.hasTopPaper ? 2 : 0)),
        presentation: 5,
        networking: 5,
      },
    };

    setPlayer(newPlayer);
    setPhase('Research Phase');
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-50 to-white py-12 px-4">
      <div className="max-w-2xl mx-auto">
        <div className="bg-white rounded-xl shadow-lg p-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Create Your Character</h1>
          <p className="text-gray-600 mb-8">
            Set up your academic profile to begin your PhD application journey
          </p>

          <form onSubmit={handleSubmit} className="space-y-6">
            {/* Name */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Your Name *
              </label>
              <input
                type="text"
                required
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                placeholder="Enter your name"
              />
            </div>

            {/* University & Major */}
            <div className="grid md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Current University *
                </label>
                <select
                  required
                  value={formData.university}
                  onChange={(e) => setFormData({ ...formData, university: e.target.value })}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                >
                  <option value="">Select...</option>
                  {UNIVERSITIES.map(uni => (
                    <option key={uni} value={uni}>{uni}</option>
                  ))}
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Major *
                </label>
                <input
                  type="text"
                  required
                  value={formData.major}
                  onChange={(e) => setFormData({ ...formData, major: e.target.value })}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                  placeholder="Your major"
                />
              </div>
            </div>

            {/* GPA */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                GPA (4.0 scale): {formData.gpa.toFixed(2)}
              </label>
              <input
                type="range"
                min="2.5"
                max="4.0"
                step="0.1"
                value={formData.gpa}
                onChange={(e) => setFormData({ ...formData, gpa: parseFloat(e.target.value) })}
                className="w-full"
              />
              <div className="flex justify-between text-xs text-gray-500 mt-1">
                <span>2.5</span>
                <span>4.0</span>
              </div>
            </div>

            {/* Research Experience */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Number of Papers
              </label>
              <input
                type="number"
                min="0"
                max="20"
                value={formData.papers}
                onChange={(e) => setFormData({ ...formData, papers: parseInt(e.target.value) })}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
              />
            </div>

            <div className="flex items-center">
              <input
                type="checkbox"
                id="topPaper"
                checked={formData.hasTopPaper}
                onChange={(e) => setFormData({ ...formData, hasTopPaper: e.target.checked })}
                className="w-4 h-4 text-blue-600 border-gray-300 rounded focus:ring-blue-500"
              />
              <label htmlFor="topPaper" className="ml-2 text-sm text-gray-700">
                I have paper(s) in top conferences/journals
              </label>
            </div>

            {/* Test Scores */}
            <div className="grid md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  TOEFL: {formData.toefl}
                </label>
                <input
                  type="range"
                  min="80"
                  max="120"
                  value={formData.toefl}
                  onChange={(e) => setFormData({ ...formData, toefl: parseInt(e.target.value) })}
                  className="w-full"
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  GRE: {formData.gre}
                </label>
                <input
                  type="range"
                  min="300"
                  max="340"
                  value={formData.gre}
                  onChange={(e) => setFormData({ ...formData, gre: parseInt(e.target.value) })}
                  className="w-full"
                />
              </div>
            </div>

            {/* Research Interest */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Target Research Field *
              </label>
              <select
                required
                value={formData.targetField}
                onChange={(e) => setFormData({ ...formData, targetField: e.target.value as ResearchField })}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
              >
                {RESEARCH_FIELDS.map(field => (
                  <option key={field} value={field}>{field}</option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Research Interest (brief description) *
              </label>
              <textarea
                required
                value={formData.researchInterest}
                onChange={(e) => setFormData({ ...formData, researchInterest: e.target.value })}
                rows={3}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500"
                placeholder="E.g., Using machine learning to model atmospheric chemistry and climate change..."
              />
            </div>

            {/* Submit */}
            <button
              type="submit"
              className="w-full py-3 bg-blue-600 text-white rounded-lg font-semibold hover:bg-blue-700 transition"
            >
              Start Your Journey →
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}
