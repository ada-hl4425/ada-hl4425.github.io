/** @type {import('next').NextConfig} */
const nextConfig = {
  output: 'export',
  images: {
    unoptimized: true,
  },
  // 如果部署在 username.github.io/phd-quest，取消下面的注释
  // basePath: '/phd-quest',
  // assetPrefix: '/phd-quest',
  
  // 如果部署在 username.github.io（根目录），保持注释状态
}

module.exports = nextConfig
