# 🚀 快速开始

## 1. 安装依赖

```bash
npm install
```

## 2. 本地运行

```bash
npm run dev
```

访问 http://localhost:3000

## 3. 部署到GitHub Pages

### 方法A: 使用脚本（推荐）

**Windows:**
```bash
setup-git.bat
```

**Mac/Linux:**
```bash
./setup-git.sh
```

### 方法B: 手动部署

```bash
# 1. 初始化Git
git init
git add .
git commit -m "Initial commit"

# 2. 连接GitHub仓库
git remote add origin https://github.com/YOUR_USERNAME/phd-quest.git
git branch -M main
git push -u origin main

# 3. 在GitHub仓库设置中启用Pages
# Settings → Pages → Source: GitHub Actions
```

## 4. 配置说明

如果你的仓库名**不是** `phd-quest`，需要修改 `next.config.js`:

```javascript
basePath: '/YOUR_REPO_NAME',
assetPrefix: '/YOUR_REPO_NAME',
```

## 📚 详细文档

- **完整指南**: 查看 `DEPLOYMENT.md`
- **命令参考**: 查看 `COMMANDS.md`
- **项目概览**: 查看 `PROJECT_SUMMARY.md`

## 🎮 游戏特色

- 📧 真实的套磁邮件系统
- 🎯 10+位真实导师
- 🏫 7所顶尖大学
- 🤖 AI驱动的个性化回复
- 📊 完整的申请追踪

## 💡 提示

- 首次运行需要安装依赖（约2分钟）
- 推送到GitHub后等待2-3分钟完成部署
- 部署完成后访问: `https://YOUR_USERNAME.github.io/phd-quest/`

祝你PhD申请顺利！🎓
